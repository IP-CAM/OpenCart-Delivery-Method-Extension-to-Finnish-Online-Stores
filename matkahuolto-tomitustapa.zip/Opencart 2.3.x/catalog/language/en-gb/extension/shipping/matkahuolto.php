<?php
// Text
$_['text_title']                      = 'Matkahuolto';
$_['text_free_cargo']                 = 'Rahtivapaasti:';
$_['text_kotijakelu']                 = 'Kotijakelu';
$_['text_decription_SE']              = 'Rahti Ruotsiin';
$_['text_decription_DK']              = 'Rahti Tanskaan';
$_['text_decription_EE']              = 'Rahti Viroon';
$_['text_decription_LT']              = 'Rahti Latviaan';
$_['text_decription_LV']              = 'Rahti Liettuaan';
$_['text_decription_DE']              = 'Rahti Saksaan';
$_['text_decription_BE']              = 'Rahti Belgiaan';
$_['text_decription_AT']              = 'Rahti Itävaltaan';
$_['text_decription_NL']              = 'Rahti Hollantiin';
$_['text_decription_LU']              = 'Rahti Luxemburgiin';

// Error
$_['error_volume']              = 'Matkahuolto: Liian suuri tilavuus';
$_['error_length']              = 'Matkahuolto: Liian pitkä paketti, maksimipituus 3 metriä';
$_['error_iso']                 = 'Matkahuolto: Liian pitkä paketti ilman Iso-lisäpalvelua! Maksimipituus 120 cm';
$_['error_home']                = 'Matkahuolto: Liian pitkä kuljetus kotijakeluun';